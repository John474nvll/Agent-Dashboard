
import React from 'react';
import { 
  LayoutDashboard, 
  Cpu, 
  MessageCircle, 
  Database, 
  Settings, 
  LogOut, 
  MessageSquareQuote 
} from 'lucide-react';

export const Sidebar = ({ activeSection, onSectionChange, onLogout }: any) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'agents', label: 'Bots & Agentes', icon: Cpu },
    { id: 'omnichannel', label: 'Canales Meta', icon: MessageCircle, badge: 'PRO' },
    { id: 'knowledge', label: 'Cerebro IA', icon: Database },
  ];

  return (
    <aside className="w-80 h-screen border-r border-forest-800 flex flex-col p-10 space-y-12 bg-forest-950 z-20 shadow-[10px_0_30px_rgba(0,0,0,0.5)]">
      <div className="flex items-center space-x-4">
        <div className="w-12 h-12 bg-accent-emerald rounded-xl flex items-center justify-center shadow-[0_0_20px_rgba(16,185,129,0.3)]">
          <MessageSquareQuote className="text-forest-950" size={28} strokeWidth={2.5} />
        </div>
        <div>
          <h1 className="text-xl font-impact tracking-widest text-white leading-none">BOTS WHATS</h1>
          <span className="text-[8px] text-accent-emerald font-black uppercase tracking-[0.4em]">Intelligence v4</span>
        </div>
      </div>

      <nav className="flex-1 space-y-3">
        {menuItems.map((item) => (
          <button 
            key={item.id}
            onClick={() => onSectionChange(item.id)}
            className={`w-full flex items-center justify-between px-6 py-4 rounded-2xl transition-all duration-300 group relative ${activeSection === item.id ? 'bg-forest-800 text-white border border-forest-700 shadow-xl' : 'text-forest-500 hover:bg-forest-900/50 hover:text-accent-emerald'}`}
          >
            <div className="flex items-center space-x-4 relative z-10">
              <item.icon size={18} className={activeSection === item.id ? 'text-accent-emerald' : 'group-hover:text-accent-emerald transition-colors'} />
              <span className="font-bold text-sm tracking-tight">{item.label}</span>
            </div>
            {item.badge && <span className="text-[8px] font-black px-2 py-0.5 rounded-md bg-accent-gold text-forest-950 uppercase relative z-10">{item.badge}</span>}
            {activeSection === item.id && <div className="absolute left-0 w-1 h-6 bg-accent-emerald rounded-full" />}
          </button>
        ))}
      </nav>

      <div className="pt-8 mt-8 border-t border-forest-800/30 space-y-2">
        <button onClick={() => onSectionChange('settings')} className="w-full flex items-center space-x-4 px-6 py-4 text-forest-500 hover:text-white transition-colors group">
          <Settings size={18} className="group-hover:rotate-45 transition-transform" />
          <span className="text-sm font-bold">Configuración</span>
        </button>
        <button onClick={onLogout} className="w-full flex items-center space-x-4 px-6 py-4 text-forest-500 hover:text-red-400 transition-colors">
          <LogOut size={18} />
          <span className="text-sm font-bold">Desconectar</span>
        </button>
      </div>
    </aside>
  );
};
