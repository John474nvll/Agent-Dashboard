
import React from 'react';
import { Sidebar } from './Sidebar';
import { ShieldCheck, User, Wifi } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  activeSection: string;
  onSectionChange: (section: any) => void;
  onLogout: () => void;
  session: { email: string; role: string } | null;
}

export const Layout = ({ children, activeSection, onSectionChange, onLogout, session }: LayoutProps) => {
  return (
    <div className="flex h-screen bg-forest-950 text-accent-cream overflow-hidden font-sans">
      <Sidebar 
        activeSection={activeSection} 
        onSectionChange={onSectionChange} 
        onLogout={onLogout} 
      />
      
      <main className="flex-1 flex flex-col overflow-hidden bg-[#010805] relative">
        <div className="absolute top-0 right-0 w-full h-96 bg-gradient-to-b from-accent-emerald/[0.03] to-transparent pointer-events-none" />
        
        <header className="h-32 border-b border-forest-800/40 flex items-center justify-between px-20 backdrop-blur-3xl sticky top-0 z-10 bg-forest-950/40">
          <div className="space-y-2">
            <h2 className="text-4xl font-display font-bold text-white tracking-tight capitalize">
               {activeSection === 'dashboard' ? 'Estadísticas' : 
                activeSection === 'agents' ? 'Gestor de Bots' : 
                activeSection === 'omnichannel' ? 'Omnicanalidad' : 
                activeSection === 'knowledge' ? 'Inteligencia' : activeSection}
            </h2>
            <div className="flex items-center space-x-4">
               <div className="flex items-center space-x-2">
                  <Wifi size={12} className="text-accent-emerald animate-pulse" />
                  <p className="text-[9px] font-black text-forest-600 uppercase tracking-[0.2em] font-mono">CORE STATUS: OPERATIONAL</p>
               </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-10">
             <div className="hidden lg:flex items-center space-x-5 px-8 py-4 bg-forest-900/60 border border-forest-800 rounded-[2rem] shadow-xl">
                <div className="w-10 h-10 bg-accent-emerald rounded-xl flex items-center justify-center text-forest-950 shadow-[0_0_15px_#10b981]">
                   <User size={20} strokeWidth={2.5} />
                </div>
                <div className="text-left">
                   <p className="text-xs font-bold text-white leading-none">{session?.role}</p>
                   <p className="text-[9px] font-medium text-forest-600 mt-1 uppercase tracking-tighter">{session?.email}</p>
                </div>
             </div>
             <div className="hidden md:flex items-center space-x-3 px-6 py-3 border border-forest-800/50 rounded-2xl group cursor-default transition-all hover:border-accent-emerald/50">
                <div className="w-2 h-2 bg-accent-emerald rounded-full animate-pulse shadow-[0_0_10px_#10b981]" />
                <span className="text-[9px] font-black text-white uppercase tracking-[0.3em] font-mono">B-WHATS-SERVER-1</span>
             </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-20 custom-scrollbar relative">
          <div className="absolute top-0 right-0 w-1/3 h-1/3 bg-accent-emerald/[0.01] blur-[120px] -z-10" />
          <div className="max-w-[1600px] mx-auto">
            {children}
          </div>
          <div className="h-32" />
        </div>
      </main>
    </div>
  );
};
