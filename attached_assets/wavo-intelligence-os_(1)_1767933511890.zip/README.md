
# SoftGAN Voice OS - Local Deployment Guide 🌲

Este proyecto es un dashboard de inteligencia de voz de baja latencia integrado con **Gemini Live API** y **Prisma ORM**.

## 🚀 Instalación Local

### 1. Requisitos previos
- Node.js v18 o superior.
- Una Gemini API Key (Obtenla en [Google AI Studio](https://aistudio.google.com/)).

### 2. Pasos para arrancar
```bash
# Instalar dependencias
npm install

# Generar el cliente de Prisma (SQLite)
npx prisma generate

# Configurar variables de entorno
# Crea un archivo .env basado en .env.example
cp .env.example .env
# Edita .env y pon tu VITE_GEMINI_API_KEY

# Iniciar servidor de desarrollo
npm run dev
```

## 🛠️ Estructura del Proyecto
- `index.tsx`: Corazón de la aplicación y lógica de la Live API.
- `schema.prisma`: Definición de la base de datos (Agents, Calls, Knowledge).
- `vite.config.ts`: Configuración del entorno de compilación.

## 📡 Conectividad Live
La aplicación utiliza WebSockets nativos para conectarse a los modelos `gemini-2.5-flash-native-audio-preview`. Asegúrate de tener una conexión a internet estable para las pruebas de voz.

---
**SoftGAN Intelligence** - *Industrial Voice Systems*
