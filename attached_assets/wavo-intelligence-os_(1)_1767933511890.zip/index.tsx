
import React, { useState, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import { LoginPage } from './features/auth/LoginPage';
import { Layout } from './components/Layout';
import { Overview } from './features/dashboard/Overview';
import { AgentManager } from './features/agents/AgentManager';
import { OmnichannelView } from './features/omnichannel/OmnichannelView';
import { KnowledgeView } from './features/knowledge/KnowledgeView';

type Section = 'dashboard' | 'agents' | 'omnichannel' | 'knowledge' | 'settings';

interface UserSession {
  email: string;
  role: string;
  token: string;
}

const App = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [session, setSession] = useState<UserSession | null>(null);
  const [activeSection, setActiveSection] = useState<Section>('dashboard');
  const [isBooting, setIsBooting] = useState(true);

  useEffect(() => {
    // Simular secuencia de arranque del sistema empresarial
    const timer = setTimeout(() => {
      const savedSession = localStorage.getItem('wavo_session');
      if (savedSession) {
        try {
          const parsed = JSON.parse(savedSession);
          setSession(parsed);
          setIsAuthenticated(true);
        } catch (e) {
          localStorage.removeItem('wavo_session');
        }
      }
      setIsBooting(false);
    }, 1000);

    const handleSessionSwitch = (e: any) => {
      handleLogin({ ...e.detail, token: 'JWT_QUICK_SWITCH_TOKEN' });
    };

    window.addEventListener('switch-session', handleSessionSwitch);
    return () => {
      clearTimeout(timer);
      window.removeEventListener('switch-session', handleSessionSwitch);
    };
  }, []);

  const handleLogin = (userCredentials: UserSession) => {
    localStorage.setItem('wavo_session', JSON.stringify(userCredentials));
    setSession(userCredentials);
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    localStorage.removeItem('wavo_session');
    setSession(null);
    setIsAuthenticated(false);
  };

  if (isBooting) {
    return (
      <div className="min-h-screen bg-forest-950 flex flex-col items-center justify-center space-y-6">
        <div className="w-16 h-16 border-4 border-accent-emerald border-t-transparent rounded-full animate-spin" />
        <p className="text-xs font-black text-forest-500 uppercase tracking-[0.5em] animate-pulse">Initializing WAVO_CORE...</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return (
    <Layout 
      activeSection={activeSection} 
      onSectionChange={setActiveSection} 
      onLogout={handleLogout}
      session={session}
    >
      <div className="animate-in fade-in slide-in-from-bottom-8 duration-1000">
        {activeSection === 'dashboard' && <Overview />}
        {activeSection === 'agents' && <AgentManager />}
        {activeSection === 'omnichannel' && <OmnichannelView />}
        {activeSection === 'knowledge' && <KnowledgeView />}
        {activeSection === 'settings' && (
          <div className="flex items-center justify-center h-[60vh] opacity-20 flex-col space-y-6">
            <div className="w-24 h-24 bg-forest-800 rounded-[2.5rem] flex items-center justify-center border border-forest-700">
              <span className="text-5xl font-black">⚙️</span>
            </div>
            <div className="text-center space-y-2">
              <p className="font-mono text-xs uppercase tracking-[0.5em] text-white">Kernel Config Locked</p>
              <p className="text-[10px] text-forest-500 font-bold uppercase tracking-widest">Root clearance required</p>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};

const root = createRoot(document.getElementById('root')!);
root.render(<App />);
