
import React, { useState } from 'react';
import { MessageSquareQuote, Lock, Star, Briefcase, Users, Fingerprint, ShieldAlert, Loader2, ShieldCheck } from 'lucide-react';

interface LoginPageProps {
  onLogin: (credentials: { email: string; role: string; token: string }) => void;
}

export const LoginPage = ({ onLogin }: LoginPageProps) => {
  const [loading, setLoading] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const loginProfiles = [
    { 
      id: 'admin', 
      name: 'Director Root', 
      email: 'root@botswhats.com', 
      role: 'Master Admin', 
      icon: Star, 
      color: 'text-accent-emerald',
      token: 'TOKEN_BOTS_WHATS_001'
    },
    { 
      id: 'ventas', 
      name: 'Ventas Elite', 
      email: 'sales@botswhats.com', 
      role: 'Sales Lead', 
      icon: Briefcase, 
      color: 'text-accent-gold',
      token: 'TOKEN_BOTS_WHATS_002'
    },
    { 
      id: 'staff', 
      name: 'Operador Core', 
      email: 'ops@botswhats.com', 
      role: 'Staff Node', 
      icon: Users, 
      color: 'text-accent-violet',
      token: 'TOKEN_BOTS_WHATS_003'
    }
  ];

  const handleProfileSelect = (profile: any) => {
    setSelectedId(profile.id);
    setLoading(true);
    setTimeout(() => {
      onLogin({ email: profile.email, role: profile.role, token: profile.token });
    }, 1200);
  };

  return (
    <div className="min-h-screen bg-forest-950 flex flex-col items-center justify-center p-8 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_50%_10%,rgba(16,185,129,0.05)_0%,transparent_50%)]" />
      
      <div className="w-full max-w-5xl z-10">
        <div className="text-center mb-16 animate-in fade-in slide-in-from-top-12 duration-1000">
          <div className="inline-flex p-5 bg-forest-900 border border-forest-800 rounded-2xl mb-8 shadow-[0_0_50px_rgba(16,185,129,0.15)] animate-float">
            <MessageSquareQuote className="text-accent-emerald" size={56} />
          </div>
          <h1 className="text-7xl font-impact text-white tracking-widest leading-none mb-4">
            BOTS <span className="text-accent-emerald">WHATS</span>
          </h1>
          <p className="text-forest-500 font-display font-medium uppercase tracking-[0.8em] text-[9px]">
            AI ORCHESTRATION PLATFORM • v4.0
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {loginProfiles.map((p, idx) => (
            <button
              key={p.id}
              onClick={() => handleProfileSelect(p)}
              disabled={loading}
              className={`glass-forest group p-12 rounded-[2.5rem] border border-forest-800/40 flex flex-col items-center text-center transition-all duration-500 hover:border-accent-emerald/40 hover:-translate-y-4 animate-in fade-in slide-in-from-bottom-12 delay-${idx * 100} ${selectedId === p.id ? 'ring-2 ring-accent-emerald border-accent-emerald' : ''}`}
            >
              <div className={`w-20 h-20 rounded-2xl bg-forest-900 flex items-center justify-center border border-forest-800 mb-8 group-hover:bg-forest-800 transition-colors ${p.color}`}>
                <p.icon size={40} />
              </div>
              <h3 className="text-2xl font-display font-bold text-white mb-2">{p.name}</h3>
              <p className="text-[10px] font-black uppercase tracking-widest text-forest-500 mb-8">{p.role}</p>
              
              <div className="w-full h-px bg-gradient-to-r from-transparent via-forest-800 to-transparent mb-8" />
              
              <div className="flex items-center space-x-3 text-forest-600 group-hover:text-accent-emerald transition-colors">
                {selectedId === p.id ? (
                  <Loader2 className="animate-spin" size={20} />
                ) : (
                  <>
                    <Fingerprint size={20} />
                    <span className="text-[11px] font-bold uppercase tracking-[0.2em]">IDENTIFICAR</span>
                  </>
                )}
              </div>
            </button>
          ))}
        </div>

        <div className="mt-20 flex flex-col items-center opacity-30">
           <div className="flex items-center space-x-8 text-forest-500 font-mono text-[9px] uppercase tracking-widest">
              <span className="flex items-center space-x-2"><ShieldCheck size={14} /> <span>ENCRYPTED</span></span>
              <span className="flex items-center space-x-2"><ShieldAlert size={14} /> <span>PROXIED</span></span>
           </div>
        </div>
      </div>
    </div>
  );
};
