
import React from 'react';
import { MessageCircle, Phone, Webhook, RefreshCcw, Key } from 'lucide-react';

export const OmnichannelView = () => {
  return (
    <div className="space-y-12 animate-in fade-in duration-700">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="glass-forest p-10 rounded-[3rem] border-forest-800/50">
           <div className="flex items-center space-x-4 mb-10">
              <div className="p-4 bg-accent-emerald/10 text-accent-emerald rounded-2xl">
                 <MessageCircle size={32} />
              </div>
              <h3 className="text-2xl font-black text-white">WhatsApp Cloud API</h3>
           </div>
           
           <div className="space-y-6 mb-10">
              <div className="p-6 bg-black/30 rounded-3xl border border-forest-800 space-y-4">
                 <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black text-forest-600 uppercase">Phone Number ID</span>
                    <span className="text-xs font-mono text-white">105934827...</span>
                 </div>
                 <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black text-forest-600 uppercase">Status</span>
                    <span className="text-[10px] font-black text-accent-emerald uppercase">Connected</span>
                 </div>
              </div>
           </div>

           <button className="w-full py-4 rounded-2xl bg-accent-emerald text-forest-950 font-black text-xs emerald-glow">CONFIGURAR WEBHOOK</button>
        </div>

        <div className="glass-forest p-10 rounded-[3rem] border-forest-800/50">
           <div className="flex items-center space-x-4 mb-10">
              <div className="p-4 bg-accent-gold/10 text-accent-gold rounded-2xl">
                 <Phone size={32} />
              </div>
              <h3 className="text-2xl font-black text-white">SIP Trunking (Voice)</h3>
           </div>
           
           <div className="flex flex-col items-center justify-center h-48 border-2 border-dashed border-forest-800 rounded-3xl opacity-30 text-center space-y-4">
              <Key size={32} />
              <p className="text-[10px] font-black uppercase tracking-widest px-10">Conecta tu proveedor de telefonía para llamadas salientes de IA</p>
           </div>
        </div>
      </div>
    </div>
  );
};
