
import React, { useState, useEffect } from 'react';
import { 
  Plus, Headphones, MessageSquare, Bot, Edit3, Trash2, Zap, Database, 
  Play, Utensils, Globe2, Sparkles, Server, Activity
} from 'lucide-react';
import { db } from '../../services/db';
import { AgentEditor } from './AgentEditor';
import { LiveConsole } from '../live/LiveConsole';

export const AgentManager = () => {
  const [agents, setAgents] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [testingAgent, setTestingAgent] = useState<any>(null);
  const [editingAgent, setEditingAgent] = useState<any>(null);
  const [isCreating, setIsCreating] = useState(false);

  const loadAgents = async () => {
    setLoading(true);
    const data = await db.agent.findMany();
    // Default data if empty
    if (data.length === 0) {
      const initial = [
        { 
          id: 'juana-001', 
          name: 'Juana • Rancho Juanda', 
          modality: 'hybrid',
          language: 'es-ES',
          model: 'gemini-3-flash-preview', 
          status: 'online',
          voice: 'Zephyr',
          stats: { sessions: '1.2k', accuracy: '98%' },
          img: 'https://images.unsplash.com/photo-1547573854-74d2a71d0826?auto=format&fit=crop&q=80&w=400',
          systemInstruction: `Eres Juana, la asistente de Rancho de Juanda...`
        }
      ];
      localStorage.setItem('prisma_agents', JSON.stringify(initial));
      setAgents(initial);
    } else {
      setAgents(data);
    }
    setLoading(false);
  };

  useEffect(() => {
    loadAgents();
  }, []);

  const handleSaveAgent = async (formData: any) => {
    if (isCreating) {
      await db.agent.create(formData);
    } else {
      await db.agent.update(formData.id, formData);
    }
    setIsCreating(false);
    setEditingAgent(null);
    loadAgents();
  };

  const handleDelete = async (id: string) => {
    if (confirm('¿Eliminar permanentemente este nodo de la base de datos?')) {
      await db.agent.delete(id);
      loadAgents();
    }
  };

  if (editingAgent || isCreating) {
    return <AgentEditor agent={editingAgent} onSave={handleSaveAgent} onCancel={() => { setEditingAgent(null); setIsCreating(false); }} />;
  }

  return (
    <div className="space-y-12 animate-in fade-in duration-700 font-section-agents pb-20">
      {/* Header Area */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-6">
          <div className="w-16 h-16 bg-accent-emerald/10 border border-accent-emerald/20 rounded-3xl flex items-center justify-center text-accent-emerald shadow-2xl">
            <Server size={32} />
          </div>
          <div>
            <h3 className="text-4xl font-display font-bold text-white tracking-tight">Agentes Inteligentes</h3>
            <div className="flex items-center space-x-3 mt-1">
              <div className="flex items-center space-x-2">
                <div className="w-1.5 h-1.5 bg-accent-emerald rounded-full animate-pulse" />
                <span className="text-[10px] font-black text-forest-500 uppercase tracking-widest">DATABASE LINK ACTIVE</span>
              </div>
              <span className="text-forest-800 font-mono text-[9px]">V4.5.1-PRISMA</span>
            </div>
          </div>
        </div>
        <button 
          onClick={() => setIsCreating(true)}
          className="bg-accent-emerald text-forest-950 px-10 py-5 rounded-2xl font-black text-xs hover:bg-white transition-all transform hover:-translate-y-1 shadow-2xl shadow-accent-emerald/20 flex items-center space-x-3 group"
        >
          <Plus size={18} strokeWidth={3} className="group-hover:rotate-90 transition-transform" />
          <span>DESPLEGAR AGENTE</span>
        </button>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-40 space-y-6 opacity-30">
          <div className="w-12 h-12 border-2 border-accent-emerald border-t-transparent rounded-full animate-spin" />
          <p className="text-[10px] font-black uppercase tracking-[0.4em]">Sincronizando con DB...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
          {agents.map((agent) => (
            <div key={agent.id} className="glass-forest rounded-[3rem] border-forest-800/40 group hover:border-accent-emerald/40 transition-all duration-500 overflow-hidden flex flex-col shadow-2xl relative">
              {/* Card Image Header */}
              <div className="h-44 relative overflow-hidden">
                <img src={agent.img} className="w-full h-full object-cover opacity-60 group-hover:scale-110 group-hover:opacity-80 transition-all duration-1000" alt={agent.name} />
                <div className="absolute inset-0 bg-gradient-to-t from-forest-950 via-forest-950/20 to-transparent" />
                
                {/* Modality Badge */}
                <div className="absolute top-6 left-8 flex items-center space-x-2 z-10">
                  <div className="bg-forest-950/80 backdrop-blur-md px-4 py-2 rounded-xl border border-forest-800 flex items-center space-x-2">
                    {agent.modality === 'voice' ? <Headphones size={14} className="text-accent-emerald" /> : 
                     agent.modality === 'chat' ? <MessageSquare size={14} className="text-accent-violet" /> : 
                     <Bot size={14} className="text-accent-gold" />}
                    <span className="text-[9px] font-black text-white uppercase tracking-widest">{agent.modality}</span>
                  </div>
                </div>

                <div className="absolute top-6 right-8 flex items-center space-x-2 z-10">
                  <button onClick={() => setEditingAgent(agent)} className="p-3 bg-forest-950/80 backdrop-blur-md rounded-xl text-forest-400 hover:text-white transition-all border border-forest-800/50"><Edit3 size={16} /></button>
                  <button onClick={() => handleDelete(agent.id)} className="p-3 bg-forest-950/80 backdrop-blur-md rounded-xl text-forest-400 hover:text-red-500 transition-all border border-forest-800/50"><Trash2 size={16} /></button>
                </div>
              </div>

              {/* Card Body */}
              <div className="p-10 flex-1 flex flex-col">
                <div className="flex items-center justify-between mb-8">
                  <div>
                    <h4 className="text-2xl font-display font-bold text-white group-hover:text-accent-emerald transition-colors leading-none">{agent.name}</h4>
                    <div className="flex items-center space-x-3 mt-2">
                       <span className="text-[9px] font-black text-forest-600 uppercase tracking-widest">{agent.language}</span>
                       <span className="w-1 h-1 bg-forest-800 rounded-full" />
                       <span className="text-[9px] font-mono text-accent-emerald">{agent.model?.split('-')[2]}</span>
                    </div>
                  </div>
                  <div className="w-14 h-14 bg-forest-900/50 rounded-2xl flex items-center justify-center text-accent-emerald border border-forest-800 group-hover:emerald-glow transition-all">
                    {agent.id.includes('juana') ? <Utensils size={28} /> : <Sparkles size={28} />}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-10">
                  <div className="p-4 bg-forest-950/50 rounded-2xl border border-forest-800 group-hover:border-forest-700 transition-colors">
                    <p className="text-[8px] font-black text-forest-600 uppercase mb-1">Confianza</p>
                    <div className="flex items-center space-x-2">
                       <Zap size={10} className="text-accent-gold" />
                       <span className="text-sm font-bold text-white tracking-tight">{agent.stats?.accuracy || '99%'}</span>
                    </div>
                  </div>
                  <div className="p-4 bg-forest-950/50 rounded-2xl border border-forest-800 group-hover:border-forest-700 transition-colors">
                    <p className="text-[8px] font-black text-forest-600 uppercase mb-1">Llamadas</p>
                    <span className="text-sm font-bold text-white tracking-tight">{agent.stats?.sessions || '0'}</span>
                  </div>
                </div>

                <button 
                  onClick={() => setTestingAgent(agent)}
                  className="w-full bg-forest-900 hover:bg-white hover:text-forest-950 text-white py-5 rounded-[1.5rem] font-black text-[10px] tracking-[0.2em] uppercase transition-all flex items-center justify-center space-x-3 border border-forest-800/50 group"
                >
                  <Play size={16} fill="currentColor" className="group-hover:translate-x-1 transition-transform" />
                  <span>PROBAR NODO</span>
                </button>
              </div>
              
              {/* Bottom Decoration */}
              <div className={`h-1.5 w-full bg-gradient-to-r ${agent.modality === 'voice' ? 'from-accent-emerald to-blue-500' : agent.modality === 'chat' ? 'from-accent-violet to-fuchsia-500' : 'from-accent-gold to-orange-500'} opacity-30`} />
            </div>
          ))}
        </div>
      )}

      {testingAgent && <LiveConsole bot={testingAgent} onClose={() => setTestingAgent(null)} />}
    </div>
  );
};
