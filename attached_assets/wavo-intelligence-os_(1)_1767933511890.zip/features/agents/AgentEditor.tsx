
import React, { useState } from 'react';
import { 
  ArrowLeft, Save, Sparkles, Mic, Settings, Zap, Database, BrainCircuit, 
  MessageSquare, Headphones, Sliders, Globe, Globe2, Bot, Languages,
  ZapOff, Ghost, Activity
} from 'lucide-react';

interface AgentEditorProps {
  agent?: any;
  onSave: (agent: any) => void;
  onCancel: () => void;
}

export const AgentEditor = ({ agent, onSave, onCancel }: AgentEditorProps) => {
  const [formData, setFormData] = useState({
    id: agent?.id || '',
    name: agent?.name || 'Nuevo Nexo IA',
    modality: agent?.modality || 'hybrid', // voice | chat | hybrid
    language: agent?.language || 'es-ES',
    model: agent?.model || 'gemini-3-flash-preview',
    voice: agent?.voice || 'Zephyr',
    systemInstruction: agent?.systemInstruction || '',
    temperature: agent?.temperature || 0.7,
    img: agent?.img || 'https://images.unsplash.com/photo-1620712943543-bcc4628c6750?auto=format&fit=crop&q=80&w=400',
    config: {
      interruptionAllowed: agent?.config?.interruptionAllowed ?? true,
      silenceTimeout: agent?.config?.silenceTimeout || 3000,
      formatJson: agent?.config?.formatJson ?? true,
      webSearch: agent?.config?.webSearch ?? false
    }
  });

  const languages = [
    { code: 'es-ES', name: 'Español', flag: '🇪🇸' },
    { code: 'en-US', name: 'English', flag: '🇺🇸' },
    { code: 'pt-BR', name: 'Português', flag: '🇧🇷' },
    { code: 'fr-FR', name: 'Français', flag: '🇫🇷' }
  ];

  const modalities = [
    { id: 'voice', name: 'Voz Live', icon: Headphones, desc: 'Optimizado para audio' },
    { id: 'chat', name: 'WhatsApp', icon: MessageSquare, desc: 'Optimizado para texto' },
    { id: 'hybrid', name: 'Híbrido', icon: Bot, desc: 'Soporte multicanal' }
  ];

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const toggleConfig = (key: string) => {
    setFormData(prev => ({
      ...prev,
      config: { ...prev.config, [key]: !(prev.config as any)[key] }
    }));
  };

  return (
    <div className="flex flex-col h-full animate-in fade-in duration-500 font-section-agents pb-20">
      {/* Header */}
      <div className="flex items-center justify-between mb-12 sticky top-0 z-20 bg-forest-950/80 backdrop-blur-md py-4">
        <div className="flex items-center space-x-6">
          <button onClick={onCancel} className="p-4 bg-forest-900 border border-forest-800 rounded-2xl text-forest-500 hover:text-white transition-all shadow-xl">
            <ArrowLeft size={20} />
          </button>
          <div>
            <h3 className="text-4xl font-display font-bold text-white tracking-tight">
              {agent ? `Configurando ${agent.name}` : 'Nuevo Despliegue de IA'}
            </h3>
            <div className="flex items-center space-x-3 mt-1">
              <span className="text-accent-emerald text-[9px] font-black uppercase tracking-[0.4em]">ADMINISTRACIÓN DE NODO NEURONAL</span>
              <span className="w-1 h-1 bg-forest-800 rounded-full" />
              <span className="text-forest-600 text-[9px] font-mono">B-WHATS-PRISMA-CLIENT</span>
            </div>
          </div>
        </div>
        <div className="flex items-center space-x-4">
           <button onClick={() => onSave(formData)} className="bg-accent-emerald text-forest-950 px-10 py-5 rounded-2xl font-black text-xs hover:bg-white transition-all transform hover:-translate-y-1 shadow-2xl shadow-accent-emerald/20 flex items-center space-x-3">
            <Save size={18} />
            <span>SINCRONIZAR DB</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 flex-1 overflow-visible">
        {/* Left Panel: Core Settings */}
        <div className="lg:col-span-4 space-y-8">
          <div className="glass-forest p-10 rounded-[3rem] border-forest-800/50 space-y-10">
            <section className="space-y-6">
              <div className="flex items-center justify-between text-accent-emerald">
                <div className="flex items-center space-x-3">
                  <Activity size={20} />
                  <h4 className="text-xs font-black uppercase tracking-widest">Identidad & Imagen</h4>
                </div>
              </div>
              
              <div className="space-y-4">
                <input 
                  name="name" 
                  value={formData.name} 
                  onChange={handleChange} 
                  placeholder="Nombre del Agente"
                  className="w-full bg-forest-950 border border-forest-800 rounded-2xl py-5 px-8 text-sm text-white focus:border-accent-emerald outline-none transition-all" 
                />
                <div className="flex items-center space-x-4">
                  <input 
                    name="img" 
                    value={formData.img} 
                    onChange={handleChange} 
                    placeholder="URL de Imagen"
                    className="flex-1 bg-forest-950 border border-forest-800 rounded-2xl py-4 px-6 text-xs text-forest-300 focus:border-accent-emerald outline-none transition-all" 
                  />
                  <div className="w-14 h-14 rounded-xl overflow-hidden border border-forest-800 shrink-0">
                    <img src={formData.img} className="w-full h-full object-cover" alt="Preview" />
                  </div>
                </div>
              </div>
            </section>

            <section className="space-y-6 pt-6 border-t border-forest-800/30">
              <div className="flex items-center space-x-3 text-accent-violet">
                <Zap size={20} />
                <h4 className="text-xs font-black uppercase tracking-widest">Modalidad del Agente</h4>
              </div>
              <div className="grid grid-cols-1 gap-3">
                {modalities.map(m => (
                  <button
                    key={m.id}
                    onClick={() => setFormData(p => ({...p, modality: m.id}))}
                    className={`flex items-center justify-between p-5 rounded-2xl border transition-all ${formData.modality === m.id ? 'bg-accent-emerald text-forest-950 border-accent-emerald' : 'bg-forest-950 text-forest-500 border-forest-800 hover:border-forest-700'}`}
                  >
                    <div className="flex items-center space-x-4">
                      <m.icon size={20} />
                      <div className="text-left">
                        <p className="text-xs font-black uppercase">{m.name}</p>
                        <p className={`text-[9px] font-bold ${formData.modality === m.id ? 'text-forest-900' : 'text-forest-700'}`}>{m.desc}</p>
                      </div>
                    </div>
                    {formData.modality === m.id && <Zap size={14} fill="currentColor" />}
                  </button>
                ))}
              </div>
            </section>

            <section className="space-y-6 pt-6 border-t border-forest-800/30">
              <div className="flex items-center space-x-3 text-accent-gold">
                <Languages size={20} />
                <h4 className="text-xs font-black uppercase tracking-widest">Idioma de Interacción</h4>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {languages.map(lang => (
                  <button
                    key={lang.code}
                    onClick={() => setFormData(p => ({...p, language: lang.code}))}
                    className={`p-4 rounded-xl border text-[10px] font-black uppercase transition-all flex items-center justify-center space-x-2 ${formData.language === lang.code ? 'bg-accent-gold text-forest-950 border-accent-gold shadow-lg shadow-accent-gold/20' : 'bg-forest-950 text-forest-500 border-forest-800'}`}
                  >
                    <span>{lang.flag}</span>
                    <span>{lang.name}</span>
                  </button>
                ))}
              </div>
            </section>
          </div>
        </div>

        {/* Right Panel: Advanced Logic */}
        <div className="lg:col-span-8 space-y-8">
          <div className="glass-forest rounded-[3rem] border-forest-800/50 flex flex-col min-h-[500px] shadow-2xl overflow-hidden">
            <div className="p-10 border-b border-forest-800/30 flex items-center justify-between bg-forest-900/10">
              <div className="flex items-center space-x-5">
                <div className="p-3 bg-accent-emerald/20 text-accent-emerald rounded-xl">
                  <BrainCircuit size={24} />
                </div>
                <div>
                  <h4 className="text-xl font-display font-bold text-white">System Prompt (The Brain)</h4>
                  <p className="text-[9px] font-black text-forest-600 uppercase tracking-widest mt-1">Lógica fundamental y restricciones de comportamiento</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                 <div className="px-4 py-2 bg-forest-950 border border-forest-800 rounded-xl text-[10px] font-mono text-accent-emerald">
                    Tokens: {formData.systemInstruction.length}
                 </div>
              </div>
            </div>
            <textarea 
              name="systemInstruction"
              value={formData.systemInstruction}
              onChange={handleChange}
              placeholder="Describe cómo debe actuar el bot, su personalidad, tono y objetivos..."
              className="flex-1 bg-transparent p-12 text-sm leading-relaxed text-forest-200 outline-none placeholder:text-forest-800 resize-none font-sans"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="glass-forest p-10 rounded-[2.5rem] border-forest-800/50 space-y-8">
              <div className="flex items-center space-x-3 text-accent-emerald">
                <Sliders size={20} />
                <h4 className="text-xs font-black uppercase tracking-widest">Control Técnico</h4>
              </div>
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs font-black text-white uppercase tracking-tight">Interrupción</p>
                    <p className="text-[9px] font-bold text-forest-600 mt-1">Permite al usuario hablar mientras el bot habla</p>
                  </div>
                  <button onClick={() => toggleConfig('interruptionAllowed')} className={`w-12 h-6 rounded-full relative transition-colors ${formData.config.interruptionAllowed ? 'bg-accent-emerald' : 'bg-forest-800'}`}>
                    <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${formData.config.interruptionAllowed ? 'left-7' : 'left-1'}`} />
                  </button>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs font-black text-white uppercase tracking-tight">Google Search</p>
                    <p className="text-[9px] font-bold text-forest-600 mt-1">Conecta el bot a internet en tiempo real</p>
                  </div>
                  <button onClick={() => toggleConfig('webSearch')} className={`w-12 h-6 rounded-full relative transition-colors ${formData.config.webSearch ? 'bg-accent-violet' : 'bg-forest-800'}`}>
                    <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${formData.config.webSearch ? 'left-7' : 'left-1'}`} />
                  </button>
                </div>
              </div>
            </div>

            <div className="glass-forest p-10 rounded-[2.5rem] border-forest-800/50 flex flex-col justify-center text-center space-y-4">
              <div className="mx-auto w-12 h-12 bg-forest-900 border border-forest-800 rounded-xl flex items-center justify-center text-forest-600">
                <Ghost size={24} />
              </div>
              <p className="text-[10px] font-black text-forest-500 uppercase tracking-widest leading-relaxed">
                Más configuraciones (Webhooks, API Keys, Context Caching) disponibles en el modo Desarrollador Root.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
