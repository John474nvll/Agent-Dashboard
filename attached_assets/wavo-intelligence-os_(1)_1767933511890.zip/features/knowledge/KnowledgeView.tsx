
import React from 'react';
import { FileCode, FileText, Globe, Link as LinkIcon, Trash2 } from 'lucide-react';

export const KnowledgeView = () => {
  const docs = [
    { name: 'WAVO_Products.pdf', size: '14.2MB', type: 'PDF', status: 'ready' },
    { name: 'FAQ_Support.csv', size: '2.1MB', type: 'CSV', status: 'ready' },
    { name: 'https://docs.wavo.ai', size: 'External', type: 'Link', status: 'syncing' },
  ];

  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      <div className="glass-forest p-12 rounded-[3.5rem] border-forest-800/50">
        <div className="flex items-center justify-between mb-12">
          <h3 className="text-2xl font-black text-white tracking-tight">Base de Conocimiento</h3>
          <div className="flex space-x-4">
             <button className="bg-forest-900 text-white px-6 py-3 rounded-2xl text-xs font-black border border-forest-800">CRAWL URL</button>
             <button className="bg-accent-emerald text-forest-950 px-8 py-3 rounded-2xl text-xs font-black">SUBIR ARCHIVO</button>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4">
          {docs.map((doc, i) => (
            <div key={i} className="p-6 bg-forest-900/30 border border-forest-800 rounded-3xl flex items-center justify-between group hover:border-accent-emerald/20 transition-all">
              <div className="flex items-center space-x-6">
                <div className="p-4 bg-forest-950 rounded-2xl text-accent-emerald">
                  {doc.type === 'Link' ? <LinkIcon size={24} /> : <FileText size={24} />}
                </div>
                <div>
                   <p className="text-sm font-black text-white">{doc.name}</p>
                   <p className="text-[10px] font-bold text-forest-600 uppercase tracking-widest">{doc.size} • {doc.type}</p>
                </div>
              </div>
              <div className="flex items-center space-x-10">
                 <span className={`text-[10px] font-black uppercase ${doc.status === 'ready' ? 'text-accent-emerald' : 'text-accent-gold animate-pulse'}`}>{doc.status}</span>
                 <button className="p-3 text-forest-700 hover:text-red-400 transition-colors"><Trash2 size={20} /></button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
