
import React, { useState, useEffect } from 'react';
import { MessageSquare, Phone, Zap, Globe, TrendingUp, Terminal as TerminalIcon, ShieldCheck, Activity, BarChart3, Database } from 'lucide-react';

const MetricCard = ({ label, value, sub, icon: Icon, color }: any) => {
  const colorMap: any = {
    emerald: 'accent-emerald',
    blue: 'blue-400',
    gold: 'accent-gold',
    violet: 'accent-violet'
  };
  const activeColor = colorMap[color] || 'accent-emerald';

  return (
    <div className="glass-forest p-10 rounded-[3rem] border-forest-800/50 group transition-all duration-700 hover:bg-forest-900/60 relative overflow-hidden shadow-2xl">
      <div className={`absolute -bottom-10 -right-10 w-48 h-48 bg-${activeColor}/5 blur-[80px] opacity-0 group-hover:opacity-100 transition-opacity duration-1000`} />
      <div className="flex items-center justify-between mb-8 relative z-10">
        <div className={`w-16 h-16 bg-forest-950 rounded-2xl flex items-center justify-center border border-forest-800 text-${activeColor} group-hover:shadow-[0_0_20px_rgba(16,185,129,0.2)] transition-all duration-500`}>
          <Icon size={32} strokeWidth={2.5} />
        </div>
        <div className="flex flex-col items-end">
          <span className={`text-[10px] font-black text-${activeColor} uppercase tracking-[0.2em] bg-${activeColor}/10 px-4 py-1.5 rounded-full border border-${activeColor}/20`}>
            {sub}
          </span>
        </div>
      </div>
      <p className="text-forest-600 font-bold text-[10px] uppercase tracking-[0.3em] mb-3 relative z-10">{label}</p>
      <h4 className="text-6xl font-display font-bold text-white tracking-tighter relative z-10">{value}</h4>
    </div>
  );
};

export const Overview = () => {
  const [logs, setLogs] = useState<string[]>([]);

  useEffect(() => {
    const events = [
      "Prisma: Agent sync completed (12 nodes).",
      "WebSocket: Voice Handshake RJ-001 connected.",
      "NLP: Gemini 3-Flash response latency 42ms.",
      "Sec: AES-256 payload verified.",
      "Knowledge: Vector DB indexed 1,240 documents.",
      "WhatsApp: Business API status 200 OK."
    ];
    
    const interval = setInterval(() => {
      const newLog = `[${new Date().toLocaleTimeString()}] ${events[Math.floor(Math.random() * events.length)]}`;
      setLogs(prev => [newLog, ...prev].slice(0, 12));
    }, 4000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-12 animate-in fade-in duration-1000 font-section-dashboard pb-20">
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-8">
        <MetricCard label="Mensajes WA" value="54.2k" sub="↑ 22%" icon={MessageSquare} color="emerald" />
        <MetricCard label="Voz IA (Min)" value="12,480" sub="98.2%" icon={Phone} color="blue" />
        <MetricCard label="Threads DB" value="1.2ms" sub="Active" icon={Database} color="violet" />
        <MetricCard label="Disponibilidad" value="99.9%" sub="Stable" icon={ShieldCheck} color="gold" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        {/* Telemetry Chart Placeholder */}
        <div className="lg:col-span-2 glass-forest rounded-[4rem] p-12 border-forest-800/40 flex flex-col h-[550px] shadow-2xl overflow-hidden relative group">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(16,185,129,0.05),transparent_40%)]" />
          <div className="flex items-center justify-between mb-12 relative z-10">
            <div className="flex items-center space-x-6">
              <div className="w-14 h-14 bg-accent-emerald/20 rounded-2xl flex items-center justify-center text-accent-emerald shadow-lg border border-accent-emerald/20">
                <Activity size={28} />
              </div>
              <div>
                <h3 className="text-3xl font-display font-bold text-white tracking-tight">Análisis de Flujo Neuronal</h3>
                <p className="text-forest-600 text-[10px] font-black uppercase tracking-widest mt-1">Monitoreo de latencia y procesamiento IA</p>
              </div>
            </div>
            <div className="flex space-x-3">
               {['1H', '24H', '7D'].map(t => (
                 <button key={t} className={`px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all ${t === '1H' ? 'bg-accent-emerald text-forest-950 border-accent-emerald' : 'bg-forest-900/50 text-forest-500 border-forest-800'}`}>
                   {t}
                 </button>
               ))}
            </div>
          </div>
          <div className="flex-1 bg-forest-950/40 border border-forest-800 rounded-[3.5rem] p-12 flex flex-col items-center justify-center relative overflow-hidden shadow-inner">
             <div className="absolute inset-0 bg-[linear-gradient(rgba(16,185,129,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(16,185,129,0.02)_1px,transparent_1px)] bg-[size:50px_50px] [mask-image:radial-gradient(ellipse_at_center,black,transparent)]" />
             <div className="flex items-end space-x-4 h-56 relative z-10">
               {[40, 65, 35, 85, 45, 95, 60, 80, 50, 90, 65, 85, 70, 95, 55, 75].map((h, i) => (
                <div key={i} className="w-5 bg-gradient-to-t from-accent-emerald/5 to-accent-emerald/40 rounded-t-xl transition-all duration-1000 group-hover:to-accent-emerald/80 animate-float shadow-[0_0_15px_rgba(16,185,129,0.1)]" style={{ height: `${h}%`, animationDelay: `${i * 150}ms` }} />
              ))}
             </div>
             <p className="mt-12 text-forest-800 font-mono text-[10px] uppercase tracking-[0.8em] animate-pulse">Scanning Data Packets...</p>
          </div>
        </div>

        {/* Console Logs */}
        <div className="glass-forest rounded-[4rem] p-12 border-forest-800/40 flex flex-col shadow-2xl relative">
          <div className="flex items-center space-x-4 mb-12">
            <div className="w-12 h-12 bg-accent-gold/20 rounded-2xl flex items-center justify-center text-accent-gold shadow-lg border border-accent-gold/20">
               <TerminalIcon size={24} />
            </div>
            <div>
              <h3 className="text-2xl font-display font-bold text-white tracking-tight">Event Console</h3>
              <p className="text-[9px] font-black text-forest-600 uppercase tracking-widest mt-1">Live Backend Feed</p>
            </div>
          </div>
          <div className="flex-1 bg-black/50 rounded-[2.5rem] p-8 font-mono text-[11px] text-forest-500 overflow-y-auto space-y-4 custom-scrollbar shadow-inner border border-forest-900">
            {logs.map((log, i) => (
              <div key={i} className="flex space-x-4 animate-in fade-in slide-in-from-left-4 transition-all">
                <span className="text-accent-emerald font-bold opacity-50">»</span>
                <span className="leading-relaxed opacity-80">{log}</span>
              </div>
            ))}
          </div>
          <div className="mt-10 pt-8 border-t border-forest-800/20 flex items-center justify-between">
            <div className="flex items-center space-x-3">
               <div className="w-2 h-2 bg-accent-emerald rounded-full animate-pulse shadow-[0_0_8px_rgba(16,185,129,1)]" />
               <span className="text-[9px] font-black text-forest-600 uppercase tracking-widest">Core v4.5 Active</span>
            </div>
            <span className="text-[10px] font-mono font-bold text-forest-700">64-BIT ARCH</span>
          </div>
        </div>
      </div>
    </div>
  );
};
