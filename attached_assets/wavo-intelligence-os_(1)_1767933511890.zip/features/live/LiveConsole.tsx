
import React, { useState, useRef, useEffect } from 'react';
import { X, Volume2, MicOff, Zap, Terminal, Smartphone, Headphones, Send, MessageSquare, Activity } from 'lucide-react';
import { GoogleGenAI, Modality, LiveServerMessage } from '@google/genai';

const API_KEY = process.env.API_KEY || (import.meta as any).env?.VITE_GEMINI_API_KEY || '';

// --- Audio Utils ---
const decode = (base64: string) => {
  const binaryString = atob(base64);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
  return bytes;
};

const encode = (bytes: Uint8Array) => {
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
};

const createBlob = (data: Float32Array): { data: string; mimeType: string } => {
  const int16 = new Int16Array(data.length);
  for (let i = 0; i < data.length; i++) int16[i] = data[i] * 32768;
  return { data: encode(new Uint8Array(int16.buffer)), mimeType: 'audio/pcm;rate=16000' };
};

const decodeAudioData = async (data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number): Promise<AudioBuffer> => {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
  }
  return buffer;
};

export const LiveConsole = ({ bot, onClose }: { bot: any, onClose: () => void }) => {
  const [isLive, setIsLive] = useState(false);
  const [status, setStatus] = useState('Standby');
  const [messages, setMessages] = useState<{role: string, text: string, type: 'voice' | 'text'}[]>([]);
  const [volume, setVolume] = useState(0);

  const audioContextRef = useRef<{ input: AudioContext; output: AudioContext } | null>(null);
  const sessionRef = useRef<any>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef(new Set<AudioBufferSourceNode>());
  const analyserRef = useRef<AnalyserNode | null>(null);

  const startSession = async () => {
    if (!API_KEY) {
      alert("API Key no configurada.");
      return;
    }

    try {
      setStatus('Connecting...');
      setIsLive(true);
      
      const ai = new GoogleGenAI({ apiKey: API_KEY });
      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextRef.current = { input: inputCtx, output: outputCtx };

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const analyser = inputCtx.createAnalyser();
      analyser.fftSize = 256;
      analyserRef.current = analyser;

      const dataArray = new Uint8Array(analyser.frequencyBinCount);
      const updateVolume = () => {
        if (!analyserRef.current || !isLive) return;
        analyserRef.current.getByteFrequencyData(dataArray);
        let sum = 0;
        for (let i = 0; i < dataArray.length; i++) sum += dataArray[i];
        setVolume(sum / dataArray.length);
        requestAnimationFrame(updateVolume);
      };
      updateVolume();

      const sessionPromise = ai.live.connect({
        model: bot.model || 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setStatus('Active');
            const source = inputCtx.createMediaStreamSource(stream);
            const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = createBlob(inputData);
              sessionPromise.then(s => s.sendRealtimeInput({ media: pcmBlob }));
            };
            source.connect(analyser);
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputCtx.destination);
          },
          onmessage: async (msg: LiveServerMessage) => {
            const audioData = msg.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (audioData) {
              const outCtx = audioContextRef.current!.output;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outCtx.currentTime);
              const buffer = await decodeAudioData(decode(audioData), outCtx, 24000, 1);
              const source = outCtx.createBufferSource();
              source.buffer = buffer;
              source.connect(outCtx.destination);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              sourcesRef.current.add(source);
            }

            if (msg.serverContent?.outputTranscription) {
              setMessages(prev => [...prev.slice(-15), {role: bot.name.split(' ')[0], text: msg.serverContent!.outputTranscription!.text, type: 'voice'}]);
            } else if (msg.serverContent?.inputTranscription) {
              setMessages(prev => [...prev.slice(-15), {role: 'Usuario', text: msg.serverContent!.inputTranscription!.text, type: 'voice'}]);
            }

            if (msg.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => { try { s.stop(); } catch(e) {} });
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }
          },
          onclose: () => setIsLive(false),
          onerror: () => setIsLive(false)
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: bot.voice || 'Zephyr' } } },
          systemInstruction: bot.systemInstruction,
          outputAudioTranscription: {},
          inputAudioTranscription: {},
        }
      });
      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error(err);
      setIsLive(false);
      setStatus('Error');
    }
  };

  const stopSession = () => {
    if (sessionRef.current) sessionRef.current.close();
    if (audioContextRef.current) {
      audioContextRef.current.input.close();
      audioContextRef.current.output.close();
    }
    setIsLive(false);
    setStatus('Standby');
    setVolume(0);
  };

  useEffect(() => {
    return () => stopSession();
  }, []);

  return (
    <div className="fixed inset-0 bg-forest-950/98 backdrop-blur-3xl z-[100] flex items-center justify-center p-6 animate-in fade-in zoom-in-95 duration-500">
      <div className="glass-forest w-full max-w-7xl h-[90vh] rounded-[4rem] border-forest-700/50 flex flex-col overflow-hidden shadow-2xl">
        
        {/* Header */}
        <div className="p-10 border-b border-forest-800/50 flex items-center justify-between bg-forest-900/30">
          <div className="flex items-center space-x-6">
             <div className="p-5 bg-accent-emerald/20 rounded-[2rem] text-accent-emerald shadow-lg shadow-accent-emerald/10 transform transition-transform hover:scale-105">
                {bot.id === 'juana-001' ? <Activity size={32} /> : <Headphones size={32} />}
             </div>
             <div>
                <h2 className="text-3xl font-black text-white">{bot.name}</h2>
                <div className="flex items-center space-x-4 mt-1">
                   <div className="flex items-center space-x-2">
                      <div className={`w-2 h-2 rounded-full ${isLive ? 'bg-accent-emerald animate-pulse shadow-[0_0_8px_#22c55e]' : 'bg-forest-700'}`} />
                      <p className="text-[10px] font-black text-forest-500 uppercase tracking-[0.2em]">{status}</p>
                   </div>
                   <div className="h-3 w-px bg-forest-800" />
                   <p className="text-[10px] font-mono text-forest-600 uppercase tracking-widest">{bot.model}</p>
                </div>
             </div>
          </div>
          <button onClick={onClose} className="p-4 hover:bg-forest-800 rounded-full transition-all text-forest-500 hover:rotate-90">
            <X size={32} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 p-10 flex flex-col lg:flex-row gap-10 overflow-hidden">
          
          {/* Interaction Area (Voice Visualizer) */}
          <div className="flex-1 flex flex-col items-center justify-center space-y-12 bg-forest-950/40 rounded-[3.5rem] border border-forest-800/40 p-12 relative overflow-hidden group">
            <div className="absolute top-8 left-10 flex items-center space-x-2 opacity-50">
               <Activity size={16} className="text-accent-emerald" />
               <span className="text-[10px] font-black uppercase tracking-widest">Voice Telemetry</span>
            </div>

            <div className="relative">
              <div 
                className="absolute inset-0 rounded-full bg-accent-emerald/10 blur-[140px] transition-all duration-75" 
                style={{ transform: `scale(${1 + volume/30})`, opacity: isLive ? 0.8 : 0 }} 
              />
              <div 
                className={`w-80 h-80 rounded-full border-[10px] flex items-center justify-center transition-all duration-700 relative z-10 shadow-2xl ${isLive ? 'border-accent-emerald emerald-glow bg-forest-900/20' : 'border-forest-800 bg-forest-900/50'}`}
                style={{ transform: isLive ? `scale(${1 + volume/100})` : 'scale(1)' }}
              >
                {isLive ? <Volume2 size={120} className="text-accent-emerald animate-pulse" /> : <MicOff size={120} className="text-forest-700" />}
              </div>
            </div>
            
            <div className="flex flex-col items-center space-y-8 relative z-20">
              {!isLive ? (
                <button 
                  onClick={startSession} 
                  className="bg-accent-emerald text-forest-950 px-24 py-8 rounded-[3rem] font-black text-xs tracking-[0.2em] shadow-2xl hover:bg-white transition-all transform active:scale-95 shadow-accent-emerald/20 flex items-center space-x-4 uppercase group-hover:px-28"
                >
                  <Zap size={24} fill="currentColor" />
                  <span>INITIALIZE VOIP CANAL</span>
                </button>
              ) : (
                <button 
                  onClick={stopSession} 
                  className="bg-red-600/20 text-red-500 border border-red-500/50 px-20 py-7 rounded-[3rem] font-black text-xs tracking-[0.2em] shadow-xl hover:bg-red-600 hover:text-white transition-all uppercase"
                >
                  DISCONNECT NODE
                </button>
              )}
              <div className="flex items-center space-x-3 bg-forest-900/50 px-6 py-2 rounded-full border border-forest-800">
                 <span className="text-[10px] font-black text-forest-500 uppercase tracking-widest">Voice ID:</span>
                 <span className="text-[10px] font-black text-accent-gold uppercase tracking-widest">{bot.voice}</span>
              </div>
            </div>
          </div>

          {/* Transcript & Message Simulator Area */}
          <div className="w-full lg:w-[550px] flex flex-col space-y-6">
            <div className="flex items-center justify-between px-6">
              <div className="flex items-center space-x-3">
                 <MessageSquare size={16} className="text-accent-emerald" />
                 <p className="text-[10px] font-black text-forest-500 uppercase tracking-[0.2em]">Omnichannel Feed</p>
              </div>
              <div className="flex items-center space-x-4">
                 <div className="flex items-center space-x-2">
                    <div className="w-1.5 h-1.5 bg-accent-emerald rounded-full" />
                    <span className="text-[9px] font-black text-white uppercase tracking-widest">WhatsApp Live</span>
                 </div>
              </div>
            </div>
            
            <div className="flex-1 bg-black/60 rounded-[4rem] p-12 border border-forest-800/50 overflow-y-auto custom-scrollbar space-y-10 flex flex-col shadow-inner backdrop-blur-md">
              {messages.length === 0 ? (
                <div className="flex-1 flex flex-col items-center justify-center opacity-10 space-y-8 text-center px-10">
                   <Terminal size={100} strokeWidth={1} />
                   <p className="font-mono text-[10px] uppercase tracking-[0.5em] leading-relaxed">
                      Handshaking sequence complete. <br/>Waiting for incoming audio packets or text triggers.
                   </p>
                </div>
              ) : (
                messages.map((m, i) => (
                  <div key={i} className={`flex flex-col ${m.role === 'Usuario' ? 'items-end' : 'items-start'} animate-in slide-in-from-bottom-8 duration-500`}>
                    <div className={`flex items-center space-x-3 mb-3 ${m.role === 'Usuario' ? 'flex-row-reverse space-x-reverse' : ''}`}>
                       <div className={`w-2 h-2 rounded-full ${m.role === 'Usuario' ? 'bg-forest-600' : 'bg-accent-gold'}`} />
                       <span className={`text-[9px] font-black uppercase tracking-[0.3em] ${m.role === 'Usuario' ? 'text-forest-600' : 'text-accent-gold'}`}>{m.role}</span>
                       <span className="text-[8px] font-mono text-forest-800 uppercase">{m.type}</span>
                    </div>
                    <div className={`p-8 rounded-[2.5rem] max-w-[95%] shadow-2xl leading-relaxed text-sm font-medium ${m.role === 'Usuario' ? 'bg-forest-800 text-white rounded-tr-none border border-forest-700/50' : 'bg-forest-700/30 text-accent-cream rounded-tl-none border border-forest-600/30'}`}>
                      {m.text}
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Simulated WhatsApp Input */}
            <div className="relative group p-1 bg-forest-900/30 rounded-[2.5rem] border border-forest-800 focus-within:border-accent-emerald/30 transition-all">
              <input 
                disabled 
                placeholder="Pruebas de Texto (WhatsApp Mock)..." 
                className="w-full bg-transparent py-6 px-10 text-sm outline-none placeholder:text-forest-700 italic text-white" 
              />
              <button className="absolute right-4 top-1/2 -translate-y-1/2 p-4 bg-forest-800 text-forest-600 rounded-3xl hover:bg-accent-emerald hover:text-forest-950 transition-all shadow-xl">
                 <Send size={20} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
