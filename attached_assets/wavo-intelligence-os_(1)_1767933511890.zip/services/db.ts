
// Simulación de Prisma Client v5.10.0
export const db = {
  agent: {
    findMany: async () => {
      const data = localStorage.getItem('prisma_agents');
      return data ? JSON.parse(data) : [];
    },
    create: async (data: any) => {
      const agents = await db.agent.findMany();
      const newAgent = { ...data, id: `cl_${Date.now()}`, createdAt: new Date() };
      localStorage.setItem('prisma_agents', JSON.stringify([...agents, newAgent]));
      return newAgent;
    },
    update: async (id: string, data: any) => {
      const agents = await db.agent.findMany();
      const updated = agents.map((a: any) => a.id === id ? { ...a, ...data } : a);
      localStorage.setItem('prisma_agents', JSON.stringify(updated));
      return updated.find((a: any) => a.id === id);
    },
    delete: async (id: string) => {
      const agents = await db.agent.findMany();
      const filtered = agents.filter((a: any) => a.id !== id);
      localStorage.setItem('prisma_agents', JSON.stringify(filtered));
      return { id };
    }
  }
};
